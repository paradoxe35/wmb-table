# Isar to SQLite Compare Tool

This Dart project can:

- extract `db.isar` from the Microsoft Store package
- convert an Isar snapshot into SQLite
- compare a candidate snapshot against `resources/database/data.sqlite`
- write both a human summary and a full machine-readable diff

## Prerequisites

- Dart SDK >= 3.11
- Linux x64
- `curl`, `unzip`, and `zip`

## Quick Start

```bash
cd tmp/isar-to-sqlite

# Install dependencies and generate Isar code
make setup

# Convert an Isar snapshot into SQLite
make migrate ISAR_SRC=/path/to/db.isar SQLITE_OUT=/path/to/data.sqlite

# Compare the current resources/database/data.sqlite against an Isar snapshot
make compare ISAR_SRC=/path/to/db.isar REPORT_DIR=reports/latest

# Download/extract the Microsoft Store package and compare it
make extract-and-compare REPORT_DIR=reports/latest

# Rebuild scripts/isar-to-sqlite.zip from this folder
make package
```

## CLI Commands

```bash
dart run bin/db_tool.dart migrate --isar ./db.isar --sqlite-out ./db.sqlite

dart run bin/db_tool.dart extract --output-dir ../msix-out
dart run bin/db_tool.dart extract --msix-file /path/to/app.msix --output-dir ../msix-out

dart run bin/db_tool.dart compare \
  --baseline-sqlite ../../resources/database/data.sqlite \
  --candidate-isar ./db.isar \
  --report-dir reports/latest

dart run bin/db_tool.dart compare \
  --baseline-sqlite ../../resources/database/data.sqlite \
  --extract \
  --extract-output-dir ../msix-out \
  --report-dir reports/latest
```

## Report Output

Each compare run writes:

- `summary.md`: readable summary with sample added/removed/changed rows
- `summary.json`: compact counts per table
- `diff.json`: full schema and row-level diff details

If the candidate is an Isar file, the generated SQLite snapshot is also written to:

- `REPORT_DIR/candidate-from-isar.sqlite`

## What Gets Compared

The tool compares both schema and data:

- added or removed tables
- added, removed, or changed columns
- added rows
- removed rows
- changed rows and per-column value diffs

Primary keys are detected from SQLite schema. For this dataset, `isar_id` and
the `sermon_series` composite key are used automatically.

## Compatibility Wrappers

The older scripts still work:

- `dart run bin/isar_reader.dart`
- `dart run bin/verify.dart`

They now call the shared migration and diff libraries used by `bin/db_tool.dart`.
