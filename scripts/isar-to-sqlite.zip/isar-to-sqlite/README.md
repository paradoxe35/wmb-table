# Isar to SQLite Migration Tool

Migrates `db.isar` (Isar v3/MDBX) to `data.sqlite` for use in the Electron app.

## Prerequisites

- Dart SDK >= 3.11
- Linux x64 (for the native `libisar.so` binary)

## Quick Start

```bash
# Rebuild SQLite from Isar source
make migrate

# Verify SQLite matches Isar exactly (field-by-field)
make verify

# Clean all generated files
make clean
```

## File Paths

| File | Default Path |
|---|---|
| Isar source | `../../resources/database/db.isar` |
| SQLite output | `../../resources/database/data.sqlite` |

Override with:
```bash
make migrate ISAR_SRC=/path/to/db.isar SQLITE_OUT=/path/to/data.sqlite
```

## What `make migrate` Does

1. Installs Dart dependencies (`dart pub get`)
2. Generates Isar collection code (`build_runner`)
3. Downloads `libisar.so` native library (if missing)
4. Reads all 13 Isar collections + link tables
5. Creates 14 SQLite tables and inserts all data
6. Verifies row counts and FK integrity
7. Copies output to `resources/database/data.sqlite`

## What `make verify` Does

Reads both `db.isar` and `data.sqlite` side-by-side and compares:
- Every row in every table (by `isar_id`)
- Every field value (strings, ints, bools)
- Every foreign key / link reference
- Many-to-many join table entries
- FK constraint integrity

Exits with code 0 if all data matches, 1 if any mismatch found.

## Schema

### 14 Tables (68,808 total rows)

```
revision (1)              - DB revision number
country (6)               - Countries
state (46)                - States → country
city (119)                - Cities → state
location (228)            - Venues → city
language (81)             - Languages (16 fields: code, title, RTL, etc.)
sermon (1207)             - Sermons (date, title, minutes) → location
series (16)               - Sermon series
sermon_series (392)       - Many-to-many: sermon ↔ series
series_translation (578)  - Series names per language → language, series
audio (18096)             - Audio files (path) → audio_title, sermon, language
audio_title (18)          - Audio source labels (e.g. "VGR")
translation (30066)       - Sermon titles per language → sermon, translator, language
translator (152)          - Translators → language
```

### Entity Relationship

```
Country 1──N State 1──N City 1──N Location 1──N Sermon
                                                  │
                        Series N──M Sermon ──1──N Audio ──1── AudioTitle
                          │                  │         └──1── Language
                          │                  │
                  SeriesTranslation      Translation ──1── Translator
                     └──1── Language       └──1── Language
```

## Project Structure

```
bin/
  isar_reader.dart    # Migration script (Isar → SQLite)
  verify.dart         # Verification script (compares both DBs)
lib/collections/
  audio.dart          # 13 Isar collection model files
  audio_title.dart    # (matching the db.isar schema exactly)
  city.dart
  country.dart
  language.dart
  location.dart
  revision.dart
  series.dart
  series_translation.dart
  sermon.dart
  state.dart
  translation.dart
  translator.dart
pubspec.yaml          # Dependencies: isar, sqlite3, path
Makefile              # Build automation
```
