import 'dart:io';

import 'package:isar/isar.dart';
import 'package:path/path.dart' as p;
import 'package:sqlite3/sqlite3.dart';

import 'package:isar_reader/collection_schemas.dart';
import 'package:isar_reader/collections/audio.dart';
import 'package:isar_reader/collections/audio_title.dart';
import 'package:isar_reader/collections/city.dart';
import 'package:isar_reader/collections/country.dart';
import 'package:isar_reader/collections/language.dart';
import 'package:isar_reader/collections/location.dart';
import 'package:isar_reader/collections/revision.dart';
import 'package:isar_reader/collections/series.dart';
import 'package:isar_reader/collections/series_translation.dart';
import 'package:isar_reader/collections/sermon.dart';
import 'package:isar_reader/collections/state.dart';
import 'package:isar_reader/collections/translation.dart';
import 'package:isar_reader/collections/translator.dart';

typedef LogFn = void Function(String message);

class TableCountSummary {
  TableCountSummary({
    required this.table,
    required this.sourceCount,
    required this.sqliteCount,
  });

  final String table;
  final int sourceCount;
  final int sqliteCount;

  bool get matches => sourceCount == sqliteCount;

  Map<String, Object> toJson() {
    return <String, Object>{
      'table': table,
      'sourceCount': sourceCount,
      'sqliteCount': sqliteCount,
      'matches': matches,
    };
  }
}

class ForeignKeyViolation {
  ForeignKeyViolation({
    required this.table,
    required this.rowId,
    required this.parentTable,
    required this.foreignKeyIndex,
  });

  final String table;
  final int? rowId;
  final String parentTable;
  final int foreignKeyIndex;

  Map<String, Object?> toJson() {
    return <String, Object?>{
      'table': table,
      'rowId': rowId,
      'parentTable': parentTable,
      'foreignKeyIndex': foreignKeyIndex,
    };
  }
}

class MigrationSummary {
  MigrationSummary({
    required this.isarPath,
    required this.sqlitePath,
    required this.tableCounts,
    required this.foreignKeyViolations,
    required this.startedAt,
    required this.completedAt,
  });

  final String isarPath;
  final String sqlitePath;
  final List<TableCountSummary> tableCounts;
  final List<ForeignKeyViolation> foreignKeyViolations;
  final DateTime startedAt;
  final DateTime completedAt;

  bool get rowCountsMatch => tableCounts.every((table) => table.matches);

  Map<String, Object> toJson() {
    return <String, Object>{
      'isarPath': isarPath,
      'sqlitePath': sqlitePath,
      'startedAt': startedAt.toUtc().toIso8601String(),
      'completedAt': completedAt.toUtc().toIso8601String(),
      'rowCountsMatch': rowCountsMatch,
      'foreignKeyViolations': foreignKeyViolations
          .map((violation) => violation.toJson())
          .toList(),
      'tableCounts': tableCounts.map((table) => table.toJson()).toList(),
    };
  }
}

Future<MigrationSummary> migrateIsarToSqlite({
  required String isarPath,
  required String sqlitePath,
  LogFn? log,
}) async {
  final logger = log ?? stdout.writeln;
  final sourceFile = File(isarPath);
  if (!sourceFile.existsSync()) {
    throw ArgumentError('Isar file not found: $isarPath');
  }

  final startedAt = DateTime.now().toUtc();
  final stagingDir = await Directory.systemTemp.createTemp('isar-migrate-');
  final stagedIsarPath = p.join(stagingDir.path, p.basename(sourceFile.path));
  sourceFile.copySync(stagedIsarPath);

  final sqliteFile = File(sqlitePath);
  sqliteFile.parent.createSync(recursive: true);
  if (sqliteFile.existsSync()) {
    sqliteFile.deleteSync();
  }

  Isar? isar;
  Database? db;

  try {
    logger('Opening Isar database: ${sourceFile.path}');
    isar = await Isar.open(
      allSchemas,
      directory: stagingDir.path,
      name: p.basenameWithoutExtension(stagedIsarPath),
      inspector: false,
    );

    logger('Creating SQLite database: ${sqliteFile.path}');
    db = sqlite3.open(sqliteFile.path);
    db.execute('PRAGMA journal_mode=WAL;');
    db.execute('PRAGMA foreign_keys=OFF;');
    _createTables(db);

    final revisions = await isar.revisions.where().findAll();
    logger('Migrating revision (${revisions.length} rows)...');
    _runBatch(db, revisions, (Revision item) {
      db!.execute(
        'INSERT INTO revision (isar_id, number) VALUES (?, ?);',
        <Object?>[item.isarId, item.number],
      );
    });

    final countries = await isar.countrys.where().findAll();
    logger('Migrating country (${countries.length} rows)...');
    _runBatch(db, countries, (Country item) {
      db!.execute(
        'INSERT INTO country (isar_id, name) VALUES (?, ?);',
        <Object?>[item.isarId, item.name],
      );
    });

    final states = await isar.states.where().findAll();
    logger('Migrating state (${states.length} rows)...');
    await _runAsyncBatch(db, states, (State item) async {
      await item.countryLink.load();
      db!.execute(
        'INSERT INTO state (isar_id, idx, name, country_id) VALUES (?, ?, ?, ?);',
        <Object?>[
          item.isarId,
          item.index,
          item.name,
          item.countryLink.value?.isarId,
        ],
      );
    });

    final cities = await isar.citys.where().findAll();
    logger('Migrating city (${cities.length} rows)...');
    await _runAsyncBatch(db, cities, (City item) async {
      await item.stateLink.load();
      db!.execute(
        'INSERT INTO city (isar_id, name, state_id) VALUES (?, ?, ?);',
        <Object?>[item.isarId, item.name, item.stateLink.value?.isarId],
      );
    });

    final locations = await isar.locations.where().findAll();
    logger('Migrating location (${locations.length} rows)...');
    await _runAsyncBatch(db, locations, (Location item) async {
      await item.cityLink.load();
      db!.execute(
        'INSERT INTO location (isar_id, name, city_id) VALUES (?, ?, ?);',
        <Object?>[item.isarId, item.name, item.cityLink.value?.isarId],
      );
    });

    final languages = await isar.languages.where().findAll();
    logger('Migrating language (${languages.length} rows)...');
    _runBatch(db, languages, (Language item) {
      db!.execute(
        '''
        INSERT INTO language (
          isar_id, audio_path, code, file_name, file_size,
          grammar_article_supported, id, index_name, is_rtl, native_title,
          revision, stemmers_supported, storage_bucket, storage_path, title,
          translations_support, url
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        ''',
        <Object?>[
          item.isarId,
          item.audioPath,
          item.code,
          item.fileName,
          item.fileSize,
          item.grammarArticleSupported ? 1 : 0,
          item.id,
          item.indexName,
          item.isRTL ? 1 : 0,
          item.nativeTitle,
          item.revision,
          item.stemmersSupported ? 1 : 0,
          item.storageBucket,
          item.storagePath,
          item.title,
          item.translationsSupport ? 1 : 0,
          item.url,
        ],
      );
    });

    final audioTitles = await isar.audioTitles.where().findAll();
    logger('Migrating audio_title (${audioTitles.length} rows)...');
    _runBatch(db, audioTitles, (AudioTitle item) {
      db!.execute(
        'INSERT INTO audio_title (isar_id, value) VALUES (?, ?);',
        <Object?>[item.isarId, item.value],
      );
    });

    final sermons = await isar.sermons.where().findAll();
    logger('Migrating sermon (${sermons.length} rows)...');
    await _runAsyncBatch(db, sermons, (Sermon item) async {
      await item.locationLink.load();
      db!.execute(
        '''
          INSERT INTO sermon (
            isar_id, date_ms, id, minutes, sorting, title,
            title_formatted, location_id
          )
          VALUES (?, ?, ?, ?, ?, ?, ?, ?);
          ''',
        <Object?>[
          item.isarId,
          item.dateMs,
          item.id,
          item.minutes,
          item.sorting,
          item.title,
          item.titleFormatted,
          item.locationLink.value?.isarId,
        ],
      );
    });

    logger('Migrating sermon_series...');
    var sermonSeriesCount = 0;
    db.execute('BEGIN;');
    for (final sermon in sermons) {
      await sermon.seriesLinks.load();
      for (final linkedSeries in sermon.seriesLinks) {
        db.execute(
          'INSERT OR IGNORE INTO sermon_series (sermon_id, series_id) VALUES (?, ?);',
          <Object?>[sermon.isarId, linkedSeries.isarId],
        );
        sermonSeriesCount++;
      }
    }
    db.execute('COMMIT;');

    final allSeries = await isar.series.where().findAll();
    logger('Migrating series (${allSeries.length} rows)...');
    _runBatch(db, allSeries, (Series item) {
      db!.execute(
        'INSERT INTO series (isar_id, id, name) VALUES (?, ?, ?);',
        <Object?>[item.isarId, item.id, item.name],
      );
    });

    final seriesTranslations = await isar.seriesTranslations.where().findAll();
    logger(
      'Migrating series_translation (${seriesTranslations.length} rows)...',
    );
    await _runAsyncBatch(db, seriesTranslations, (
      SeriesTranslation item,
    ) async {
      await item.languageLink.load();
      await item.seriesLink.load();
      db!.execute(
        '''
          INSERT INTO series_translation (isar_id, name, language_id, series_id)
          VALUES (?, ?, ?, ?);
          ''',
        <Object?>[
          item.isarId,
          item.name,
          item.languageLink.value?.isarId,
          item.seriesLink.value?.isarId,
        ],
      );
    });

    final translators = await isar.translators.where().findAll();
    logger('Migrating translator (${translators.length} rows)...');
    await _runAsyncBatch(db, translators, (Translator item) async {
      await item.languageLink.load();
      db!.execute(
        '''
          INSERT INTO translator (
            isar_id, id, long_name, name, translator_id, language_id
          )
          VALUES (?, ?, ?, ?, ?, ?);
          ''',
        <Object?>[
          item.isarId,
          item.id,
          item.longName,
          item.name,
          item.translatorId,
          item.languageLink.value?.isarId,
        ],
      );
    });

    final translations = await isar.translations.where().findAll();
    logger('Migrating translation (${translations.length} rows)...');
    await _runAsyncBatch(
      db,
      translations,
      (Translation item) async {
        await item.sermonLink.load();
        await item.translatorLink.load();
        await item.languageLink.load();
        db!.execute(
          '''
          INSERT INTO translation (
            isar_id, title, title_formatted, sermon_id, translator_id, language_id
          )
          VALUES (?, ?, ?, ?, ?, ?);
          ''',
          <Object?>[
            item.isarId,
            item.title,
            item.titleFormatted,
            item.sermonLink.value?.isarId,
            item.translatorLink.value?.isarId,
            item.languageLink.value?.isarId,
          ],
        );
      },
      batchSize: 5000,
      onBatchProgress: (processed, total) {
        logger('  translation progress: $processed / $total');
      },
    );

    final audios = await isar.audios.where().findAll();
    logger('Migrating audio (${audios.length} rows)...');
    await _runAsyncBatch(
      db,
      audios,
      (Audio item) async {
        await item.titleLink.load();
        await item.sermonLink.load();
        await item.languageLink.load();
        db!.execute(
          '''
          INSERT INTO audio (isar_id, path, title_id, sermon_id, language_id)
          VALUES (?, ?, ?, ?, ?);
          ''',
          <Object?>[
            item.isarId,
            item.path,
            item.titleLink.value?.isarId,
            item.sermonLink.value?.isarId,
            item.languageLink.value?.isarId,
          ],
        );
      },
      batchSize: 5000,
      onBatchProgress: (processed, total) {
        logger('  audio progress: $processed / $total');
      },
    );

    final tableCounts = <TableCountSummary>[
      _countRows(db, 'revision', revisions.length),
      _countRows(db, 'country', countries.length),
      _countRows(db, 'state', states.length),
      _countRows(db, 'city', cities.length),
      _countRows(db, 'location', locations.length),
      _countRows(db, 'language', languages.length),
      _countRows(db, 'audio_title', audioTitles.length),
      _countRows(db, 'sermon', sermons.length),
      _countRows(db, 'series', allSeries.length),
      _countRows(db, 'series_translation', seriesTranslations.length),
      _countRows(db, 'translator', translators.length),
      _countRows(db, 'translation', translations.length),
      _countRows(db, 'audio', audios.length),
      _countRows(db, 'sermon_series', sermonSeriesCount),
    ];

    final foreignKeyViolations = db
        .select('PRAGMA foreign_key_check;')
        .map(
          (row) => ForeignKeyViolation(
            table: row['table'] as String? ?? '',
            rowId: row['rowid'] as int?,
            parentTable: row['parent'] as String? ?? '',
            foreignKeyIndex: row['fkid'] as int? ?? 0,
          ),
        )
        .toList();

    return MigrationSummary(
      isarPath: sourceFile.path,
      sqlitePath: sqliteFile.path,
      tableCounts: tableCounts,
      foreignKeyViolations: foreignKeyViolations,
      startedAt: startedAt,
      completedAt: DateTime.now().toUtc(),
    );
  } finally {
    db?.dispose();
    if (isar != null) {
      await isar.close();
    }
    if (stagingDir.existsSync()) {
      stagingDir.deleteSync(recursive: true);
    }
  }
}

TableCountSummary _countRows(Database db, String table, int sourceCount) {
  final result = db.select('SELECT COUNT(*) AS cnt FROM $table;');
  return TableCountSummary(
    table: table,
    sourceCount: sourceCount,
    sqliteCount: result.first['cnt'] as int,
  );
}

void _runBatch<T>(Database db, List<T> items, void Function(T item) action) {
  db.execute('BEGIN;');
  for (final item in items) {
    action(item);
  }
  db.execute('COMMIT;');
}

Future<void> _runAsyncBatch<T>(
  Database db,
  List<T> items,
  Future<void> Function(T item) action, {
  int batchSize = 0,
  void Function(int processed, int total)? onBatchProgress,
}) async {
  db.execute('BEGIN;');
  var processed = 0;
  for (final item in items) {
    await action(item);
    processed++;
    if (batchSize > 0 &&
        processed % batchSize == 0 &&
        processed < items.length) {
      db.execute('COMMIT;');
      onBatchProgress?.call(processed, items.length);
      db.execute('BEGIN;');
    }
  }
  db.execute('COMMIT;');
}

void _createTables(Database db) {
  db.execute('''
    CREATE TABLE revision (
      isar_id INTEGER PRIMARY KEY,
      number INTEGER NOT NULL
    );
  ''');

  db.execute('''
    CREATE TABLE country (
      isar_id INTEGER PRIMARY KEY,
      name TEXT NOT NULL
    );
  ''');

  db.execute('''
    CREATE TABLE state (
      isar_id INTEGER PRIMARY KEY,
      idx TEXT NOT NULL,
      name TEXT NOT NULL,
      country_id INTEGER REFERENCES country(isar_id)
    );
  ''');

  db.execute('''
    CREATE TABLE city (
      isar_id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      state_id INTEGER REFERENCES state(isar_id)
    );
  ''');

  db.execute('''
    CREATE TABLE location (
      isar_id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      city_id INTEGER REFERENCES city(isar_id)
    );
  ''');

  db.execute('''
    CREATE TABLE language (
      isar_id INTEGER PRIMARY KEY,
      audio_path TEXT NOT NULL,
      code TEXT NOT NULL,
      file_name TEXT NOT NULL,
      file_size TEXT NOT NULL,
      grammar_article_supported INTEGER NOT NULL DEFAULT 0,
      id TEXT NOT NULL,
      index_name TEXT NOT NULL,
      is_rtl INTEGER NOT NULL DEFAULT 0,
      native_title TEXT NOT NULL,
      revision INTEGER NOT NULL,
      stemmers_supported INTEGER NOT NULL DEFAULT 0,
      storage_bucket TEXT NOT NULL,
      storage_path TEXT NOT NULL,
      title TEXT NOT NULL,
      translations_support INTEGER NOT NULL DEFAULT 0,
      url TEXT NOT NULL
    );
  ''');

  db.execute('''
    CREATE TABLE sermon (
      isar_id INTEGER PRIMARY KEY,
      date_ms INTEGER NOT NULL,
      id TEXT NOT NULL,
      minutes INTEGER NOT NULL,
      sorting INTEGER NOT NULL,
      title TEXT NOT NULL,
      title_formatted TEXT NOT NULL,
      location_id INTEGER REFERENCES location(isar_id)
    );
  ''');

  db.execute('''
    CREATE TABLE audio_title (
      isar_id INTEGER PRIMARY KEY,
      value TEXT NOT NULL
    );
  ''');

  db.execute('''
    CREATE TABLE audio (
      isar_id INTEGER PRIMARY KEY,
      path TEXT NOT NULL,
      title_id INTEGER REFERENCES audio_title(isar_id),
      sermon_id INTEGER REFERENCES sermon(isar_id),
      language_id INTEGER REFERENCES language(isar_id)
    );
  ''');

  db.execute('''
    CREATE TABLE translator (
      isar_id INTEGER PRIMARY KEY,
      id TEXT NOT NULL,
      long_name TEXT NOT NULL,
      name TEXT NOT NULL,
      translator_id INTEGER NOT NULL,
      language_id INTEGER REFERENCES language(isar_id)
    );
  ''');

  db.execute('''
    CREATE TABLE translation (
      isar_id INTEGER PRIMARY KEY,
      title TEXT NOT NULL,
      title_formatted TEXT NOT NULL,
      sermon_id INTEGER REFERENCES sermon(isar_id),
      translator_id INTEGER REFERENCES translator(isar_id),
      language_id INTEGER REFERENCES language(isar_id)
    );
  ''');

  db.execute('''
    CREATE TABLE series (
      isar_id INTEGER PRIMARY KEY,
      id TEXT NOT NULL,
      name TEXT NOT NULL
    );
  ''');

  db.execute('''
    CREATE TABLE series_translation (
      isar_id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      language_id INTEGER REFERENCES language(isar_id),
      series_id INTEGER REFERENCES series(isar_id)
    );
  ''');

  db.execute('''
    CREATE TABLE sermon_series (
      sermon_id INTEGER NOT NULL REFERENCES sermon(isar_id),
      series_id INTEGER NOT NULL REFERENCES series(isar_id),
      PRIMARY KEY (sermon_id, series_id)
    );
  ''');
}
