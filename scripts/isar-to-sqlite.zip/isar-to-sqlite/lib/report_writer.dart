import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;

import 'package:isar_reader/sqlite_diff.dart';

class ReportArtifacts {
  ReportArtifacts({
    required this.outputDirectory,
    required this.summaryMarkdownPath,
    required this.summaryJsonPath,
    required this.diffJsonPath,
  });

  final String outputDirectory;
  final String summaryMarkdownPath;
  final String summaryJsonPath;
  final String diffJsonPath;
}

Future<ReportArtifacts> writeDiffReport(
  DatabaseDiff diff, {
  required String outputDirectory,
  int sampleLimit = 5,
}) async {
  final outputDir = Directory(outputDirectory);
  outputDir.createSync(recursive: true);

  final summaryMarkdownPath = p.join(outputDir.path, 'summary.md');
  final summaryJsonPath = p.join(outputDir.path, 'summary.json');
  final diffJsonPath = p.join(outputDir.path, 'diff.json');

  final encoder = const JsonEncoder.withIndent('  ');
  File(summaryJsonPath).writeAsStringSync(
    encoder.convert(<String, Object>{
      'baselinePath': diff.baselinePath,
      'candidatePath': diff.candidatePath,
      'startedAt': diff.startedAt.toUtc().toIso8601String(),
      'completedAt': diff.completedAt.toUtc().toIso8601String(),
      'hasDifferences': diff.hasDifferences,
      'summary': diff.summary,
      'tables': diff.tables.map((table) => table.toSummaryJson()).toList(),
    }),
  );
  File(diffJsonPath).writeAsStringSync(encoder.convert(diff.toJson()));
  File(
    summaryMarkdownPath,
  ).writeAsStringSync(_buildMarkdownSummary(diff, sampleLimit: sampleLimit));

  return ReportArtifacts(
    outputDirectory: outputDir.path,
    summaryMarkdownPath: summaryMarkdownPath,
    summaryJsonPath: summaryJsonPath,
    diffJsonPath: diffJsonPath,
  );
}

String buildConsoleSummary(DatabaseDiff diff) {
  final buffer = StringBuffer()
    ..writeln('Baseline: ${diff.baselinePath}')
    ..writeln('Candidate: ${diff.candidatePath}')
    ..writeln('Tables checked: ${diff.tables.length}')
    ..writeln(
      'Tables with differences: ${diff.summary['tablesWithDifferences']}',
    )
    ..writeln('Rows added: ${diff.summary['totalAddedRows']}')
    ..writeln('Rows removed: ${diff.summary['totalRemovedRows']}')
    ..writeln('Rows changed: ${diff.summary['totalChangedRows']}');

  final changedTables = diff.tables.where((table) => table.hasDifferences);
  for (final table in changedTables) {
    buffer.writeln(
      '  ${table.name}: +${table.addedRows.length} -${table.removedRows.length} ~${table.changedRows.length}'
      ' | columns +${table.addedColumns.length} -${table.removedColumns.length} ~${table.changedColumns.length}',
    );
  }
  if (!diff.hasDifferences) {
    buffer.writeln('No differences found.');
  }

  return buffer.toString().trimRight();
}

String _buildMarkdownSummary(DatabaseDiff diff, {required int sampleLimit}) {
  final buffer = StringBuffer()
    ..writeln('# Database Diff Summary')
    ..writeln()
    ..writeln('- Compared at: ${diff.completedAt.toUtc().toIso8601String()}')
    ..writeln('- Baseline: `${diff.baselinePath}`')
    ..writeln('- Candidate: `${diff.candidatePath}`')
    ..writeln('- Tables checked: ${diff.tables.length}')
    ..writeln(
      '- Tables with differences: ${diff.summary['tablesWithDifferences']}',
    )
    ..writeln('- Rows added: ${diff.summary['totalAddedRows']}')
    ..writeln('- Rows removed: ${diff.summary['totalRemovedRows']}')
    ..writeln('- Rows changed: ${diff.summary['totalChangedRows']}')
    ..writeln();

  if (!diff.hasDifferences) {
    buffer.writeln('The databases match exactly.');
    return buffer.toString();
  }

  for (final table in diff.tables.where((table) => table.hasDifferences)) {
    buffer
      ..writeln('## ${table.name}')
      ..writeln()
      ..writeln('- Baseline rows: ${table.baselineRowCount}')
      ..writeln('- Candidate rows: ${table.candidateRowCount}')
      ..writeln('- Key columns: `${table.keyColumns.join(', ')}`')
      ..writeln('- Added columns: ${table.addedColumns.length}')
      ..writeln('- Removed columns: ${table.removedColumns.length}')
      ..writeln('- Changed columns: ${table.changedColumns.length}')
      ..writeln('- Added rows: ${table.addedRows.length}')
      ..writeln('- Removed rows: ${table.removedRows.length}')
      ..writeln('- Changed rows: ${table.changedRows.length}')
      ..writeln();

    if (table.addedColumns.isNotEmpty) {
      buffer
        ..writeln('Added columns:')
        ..writeln('```json')
        ..writeln(
          const JsonEncoder.withIndent('  ').convert(
            table.addedColumns.map((column) => column.toJson()).toList(),
          ),
        )
        ..writeln('```')
        ..writeln();
    }

    if (table.removedColumns.isNotEmpty) {
      buffer
        ..writeln('Removed columns:')
        ..writeln('```json')
        ..writeln(
          const JsonEncoder.withIndent('  ').convert(
            table.removedColumns.map((column) => column.toJson()).toList(),
          ),
        )
        ..writeln('```')
        ..writeln();
    }

    if (table.changedColumns.isNotEmpty) {
      buffer
        ..writeln('Changed columns:')
        ..writeln('```json')
        ..writeln(
          const JsonEncoder.withIndent('  ').convert(
            table.changedColumns.map((column) => column.toJson()).toList(),
          ),
        )
        ..writeln('```')
        ..writeln();
    }

    _appendSampleRows(
      buffer,
      title: 'Sample added rows',
      rows: table.addedRows,
      sampleLimit: sampleLimit,
    );
    _appendSampleRows(
      buffer,
      title: 'Sample removed rows',
      rows: table.removedRows,
      sampleLimit: sampleLimit,
    );
    _appendSampleRows(
      buffer,
      title: 'Sample changed rows',
      rows: table.changedRows,
      sampleLimit: sampleLimit,
    );
  }

  return buffer.toString();
}

void _appendSampleRows(
  StringBuffer buffer, {
  required String title,
  required List<RowChange> rows,
  required int sampleLimit,
}) {
  if (rows.isEmpty) {
    return;
  }

  buffer
    ..writeln('$title:')
    ..writeln('```json')
    ..writeln(
      const JsonEncoder.withIndent(
        '  ',
      ).convert(rows.take(sampleLimit).map((row) => row.toJson()).toList()),
    )
    ..writeln('```')
    ..writeln();
}
