import 'package:isar/isar.dart';

part 'audio_title.g.dart';

@collection
class AudioTitle {
  Id isarId = Isar.autoIncrement;
  late String value;
}
