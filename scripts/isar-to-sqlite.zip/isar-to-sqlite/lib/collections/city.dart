import 'package:isar/isar.dart';
import 'state.dart';
import 'location.dart';

part 'city.g.dart';

@collection
class City {
  Id isarId = Isar.autoIncrement;
  late String name;

  final stateLink = IsarLink<State>();
  final locationsLinks = IsarLinks<Location>();
}
