import 'package:isar/isar.dart';
import 'sermon.dart';
import 'translator.dart';
import 'language.dart';

part 'translation.g.dart';

@collection
class Translation {
  Id isarId = Isar.autoIncrement;
  late String title;
  late String titleFormatted;

  final sermonLink = IsarLink<Sermon>();
  final translatorLink = IsarLink<Translator>();
  final languageLink = IsarLink<Language>();
}
