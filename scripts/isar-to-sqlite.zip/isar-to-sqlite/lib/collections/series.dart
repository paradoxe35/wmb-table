import 'package:isar/isar.dart';
import 'sermon.dart';
import 'series_translation.dart';

part 'series.g.dart';

@collection
class Series {
  Id isarId = Isar.autoIncrement;
  late String id;
  late String name;

  final sermonsLinks = IsarLinks<Sermon>();
  final translationsLinks = IsarLinks<SeriesTranslation>();
}
