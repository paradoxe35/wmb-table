import 'package:isar/isar.dart';
import 'location.dart';
import 'series.dart';
import 'translation.dart';
import 'audio.dart';

part 'sermon.g.dart';

@collection
class Sermon {
  Id isarId = Isar.autoIncrement;
  late int dateMs;
  late String id;
  late int minutes;
  late int sorting;
  late String title;
  late String titleFormatted;

  final locationLink = IsarLink<Location>();
  final seriesLinks = IsarLinks<Series>();
  final translationsLinks = IsarLinks<Translation>();
  final audioLinks = IsarLinks<Audio>();
}
