import 'package:isar/isar.dart';

part 'revision.g.dart';

@collection
class Revision {
  Id isarId = Isar.autoIncrement;
  late int number;
}
