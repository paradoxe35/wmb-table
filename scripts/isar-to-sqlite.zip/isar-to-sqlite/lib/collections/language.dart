import 'package:isar/isar.dart';
import 'audio.dart';
import 'translation.dart';

part 'language.g.dart';

@collection
class Language {
  Id isarId = Isar.autoIncrement;
  late String audioPath;
  late String code;
  late String fileName;
  late String fileSize;
  late bool grammarArticleSupported;
  late String id;
  late String indexName;
  late bool isRTL;
  late String nativeTitle;
  late int revision;
  late bool stemmersSupported;
  late String storageBucket;
  late String storagePath;
  late String title;
  late bool translationsSupport;
  late String url;

  final audiosLinks = IsarLinks<Audio>();
  final translationsLinks = IsarLinks<Translation>();
}
