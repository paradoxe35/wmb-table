import 'package:isar/isar.dart';
import 'audio_title.dart';
import 'sermon.dart';
import 'language.dart';

part 'audio.g.dart';

@collection
class Audio {
  Id isarId = Isar.autoIncrement;
  late String path;

  final titleLink = IsarLink<AudioTitle>();
  final sermonLink = IsarLink<Sermon>();
  final languageLink = IsarLink<Language>();
}
