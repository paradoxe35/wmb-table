import 'package:isar/isar.dart';
import 'language.dart';
import 'series.dart';

part 'series_translation.g.dart';

@collection
class SeriesTranslation {
  Id isarId = Isar.autoIncrement;
  late String name;

  final languageLink = IsarLink<Language>();
  final seriesLink = IsarLink<Series>();
}
