import 'package:isar/isar.dart';
import 'state.dart';

part 'country.g.dart';

@collection
class Country {
  Id isarId = Isar.autoIncrement;
  late String name;

  final statesLinks = IsarLinks<State>();
}
