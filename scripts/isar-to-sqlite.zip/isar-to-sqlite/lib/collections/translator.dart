import 'package:isar/isar.dart';
import 'language.dart';

part 'translator.g.dart';

@collection
class Translator {
  Id isarId = Isar.autoIncrement;
  late String id;
  late String longName;
  late String name;
  late int translatorId;

  final languageLink = IsarLink<Language>();
}
