import 'package:isar/isar.dart';
import 'city.dart';
import 'sermon.dart';

part 'location.g.dart';

@collection
class Location {
  Id isarId = Isar.autoIncrement;
  late String name;

  final cityLink = IsarLink<City>();
  final sermonsLinks = IsarLinks<Sermon>();
}
