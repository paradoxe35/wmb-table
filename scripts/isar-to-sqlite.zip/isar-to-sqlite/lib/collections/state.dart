import 'package:isar/isar.dart';
import 'country.dart';
import 'city.dart';

part 'state.g.dart';

@collection
class State {
  Id isarId = Isar.autoIncrement;
  late String index;
  late String name;

  final countryLink = IsarLink<Country>();
  final citiesLinks = IsarLinks<City>();
}
