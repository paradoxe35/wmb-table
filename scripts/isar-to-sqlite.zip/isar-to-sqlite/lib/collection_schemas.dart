import 'package:isar/isar.dart';
import 'package:isar_reader/collections/audio.dart';
import 'package:isar_reader/collections/audio_title.dart';
import 'package:isar_reader/collections/city.dart';
import 'package:isar_reader/collections/country.dart';
import 'package:isar_reader/collections/language.dart';
import 'package:isar_reader/collections/location.dart';
import 'package:isar_reader/collections/revision.dart';
import 'package:isar_reader/collections/series.dart';
import 'package:isar_reader/collections/series_translation.dart';
import 'package:isar_reader/collections/sermon.dart';
import 'package:isar_reader/collections/state.dart';
import 'package:isar_reader/collections/translation.dart';
import 'package:isar_reader/collections/translator.dart';

final List<CollectionSchema<dynamic>> allSchemas = <CollectionSchema<dynamic>>[
  AudioSchema,
  AudioTitleSchema,
  CitySchema,
  CountrySchema,
  LanguageSchema,
  LocationSchema,
  RevisionSchema,
  SeriesSchema,
  SeriesTranslationSchema,
  SermonSchema,
  StateSchema,
  TranslationSchema,
  TranslatorSchema,
];
