import 'dart:convert';
import 'dart:typed_data';

import 'package:sqlite3/sqlite3.dart';

class ColumnInfo {
  ColumnInfo({
    required this.name,
    required this.type,
    required this.notNull,
    required this.defaultValue,
    required this.primaryKeyPosition,
  });

  final String name;
  final String type;
  final bool notNull;
  final Object? defaultValue;
  final int primaryKeyPosition;

  Map<String, Object?> toJson() {
    return <String, Object?>{
      'name': name,
      'type': type,
      'notNull': notNull,
      'defaultValue': defaultValue,
      'primaryKeyPosition': primaryKeyPosition,
    };
  }
}

class ColumnChange {
  ColumnChange({required this.baseline, required this.candidate});

  final ColumnInfo baseline;
  final ColumnInfo candidate;

  Map<String, Object> toJson() {
    return <String, Object>{
      'baseline': baseline.toJson(),
      'candidate': candidate.toJson(),
    };
  }
}

class ValueChange {
  ValueChange({required this.baseline, required this.candidate});

  final Object? baseline;
  final Object? candidate;

  Map<String, Object?> toJson() {
    return <String, Object?>{
      'baseline': _normalizeValue(baseline),
      'candidate': _normalizeValue(candidate),
    };
  }
}

class RowChange {
  RowChange({
    required this.key,
    this.baselineRow,
    this.candidateRow,
    this.differences = const <String, ValueChange>{},
  });

  final Map<String, Object?> key;
  final Map<String, Object?>? baselineRow;
  final Map<String, Object?>? candidateRow;
  final Map<String, ValueChange> differences;

  Map<String, Object?> toJson() {
    return <String, Object?>{
      'key': _normalizeMap(key),
      'baselineRow': baselineRow == null ? null : _normalizeMap(baselineRow!),
      'candidateRow': candidateRow == null
          ? null
          : _normalizeMap(candidateRow!),
      'differences': differences.map(
        (column, diff) => MapEntry<String, Object?>(column, diff.toJson()),
      ),
    };
  }
}

class TableDiff {
  TableDiff({
    required this.name,
    required this.existsInBaseline,
    required this.existsInCandidate,
    required this.baselineColumns,
    required this.candidateColumns,
    required this.keyColumns,
    required this.baselineRowCount,
    required this.candidateRowCount,
    required this.addedColumns,
    required this.removedColumns,
    required this.changedColumns,
    required this.addedRows,
    required this.removedRows,
    required this.changedRows,
  });

  final String name;
  final bool existsInBaseline;
  final bool existsInCandidate;
  final List<ColumnInfo> baselineColumns;
  final List<ColumnInfo> candidateColumns;
  final List<String> keyColumns;
  final int baselineRowCount;
  final int candidateRowCount;
  final List<ColumnInfo> addedColumns;
  final List<ColumnInfo> removedColumns;
  final List<ColumnChange> changedColumns;
  final List<RowChange> addedRows;
  final List<RowChange> removedRows;
  final List<RowChange> changedRows;

  bool get hasSchemaChanges =>
      !existsInBaseline ||
      !existsInCandidate ||
      addedColumns.isNotEmpty ||
      removedColumns.isNotEmpty ||
      changedColumns.isNotEmpty;

  bool get hasRowChanges =>
      addedRows.isNotEmpty || removedRows.isNotEmpty || changedRows.isNotEmpty;

  bool get hasDifferences => hasSchemaChanges || hasRowChanges;

  Map<String, Object> toSummaryJson() {
    return <String, Object>{
      'name': name,
      'existsInBaseline': existsInBaseline,
      'existsInCandidate': existsInCandidate,
      'keyColumns': keyColumns,
      'baselineRowCount': baselineRowCount,
      'candidateRowCount': candidateRowCount,
      'addedColumns': addedColumns.length,
      'removedColumns': removedColumns.length,
      'changedColumns': changedColumns.length,
      'addedRows': addedRows.length,
      'removedRows': removedRows.length,
      'changedRows': changedRows.length,
      'hasDifferences': hasDifferences,
    };
  }

  Map<String, Object> toJson() {
    return <String, Object>{
      'summary': toSummaryJson(),
      'baselineColumns': baselineColumns
          .map((column) => column.toJson())
          .toList(),
      'candidateColumns': candidateColumns
          .map((column) => column.toJson())
          .toList(),
      'addedColumns': addedColumns.map((column) => column.toJson()).toList(),
      'removedColumns': removedColumns
          .map((column) => column.toJson())
          .toList(),
      'changedColumns': changedColumns
          .map((column) => column.toJson())
          .toList(),
      'addedRows': addedRows.map((row) => row.toJson()).toList(),
      'removedRows': removedRows.map((row) => row.toJson()).toList(),
      'changedRows': changedRows.map((row) => row.toJson()).toList(),
    };
  }
}

class DatabaseDiff {
  DatabaseDiff({
    required this.baselinePath,
    required this.candidatePath,
    required this.startedAt,
    required this.completedAt,
    required this.tables,
  });

  final String baselinePath;
  final String candidatePath;
  final DateTime startedAt;
  final DateTime completedAt;
  final List<TableDiff> tables;

  bool get hasDifferences => tables.any((table) => table.hasDifferences);

  Map<String, Object> get summary {
    final differingTables = tables
        .where((table) => table.hasDifferences)
        .toList();
    return <String, Object>{
      'tableCount': tables.length,
      'tablesWithDifferences': differingTables.length,
      'tablesAdded': tables
          .where((table) => !table.existsInBaseline && table.existsInCandidate)
          .length,
      'tablesRemoved': tables
          .where((table) => table.existsInBaseline && !table.existsInCandidate)
          .length,
      'tablesWithSchemaChanges': tables
          .where((table) => table.hasSchemaChanges)
          .length,
      'tablesWithRowChanges': tables
          .where((table) => table.hasRowChanges)
          .length,
      'totalAddedRows': tables.fold<int>(
        0,
        (sum, table) => sum + table.addedRows.length,
      ),
      'totalRemovedRows': tables.fold<int>(
        0,
        (sum, table) => sum + table.removedRows.length,
      ),
      'totalChangedRows': tables.fold<int>(
        0,
        (sum, table) => sum + table.changedRows.length,
      ),
    };
  }

  Map<String, Object> toJson() {
    return <String, Object>{
      'baselinePath': baselinePath,
      'candidatePath': candidatePath,
      'startedAt': startedAt.toUtc().toIso8601String(),
      'completedAt': completedAt.toUtc().toIso8601String(),
      'hasDifferences': hasDifferences,
      'summary': summary,
      'tables': tables.map((table) => table.toJson()).toList(),
    };
  }
}

DatabaseDiff compareSqliteDatabases({
  required String baselinePath,
  required String candidatePath,
}) {
  final startedAt = DateTime.now().toUtc();
  final baselineDb = sqlite3.open(baselinePath);
  final candidateDb = sqlite3.open(candidatePath);

  try {
    final baselineTables = _tableNames(baselineDb).toSet();
    final candidateTables = _tableNames(candidateDb).toSet();
    final allTables = <String>{...baselineTables, ...candidateTables}.toList()
      ..sort();

    final tables = <TableDiff>[];
    for (final tableName in allTables) {
      final existsInBaseline = baselineTables.contains(tableName);
      final existsInCandidate = candidateTables.contains(tableName);
      final baselineColumns = existsInBaseline
          ? _tableInfo(baselineDb, tableName)
          : <ColumnInfo>[];
      final candidateColumns = existsInCandidate
          ? _tableInfo(candidateDb, tableName)
          : <ColumnInfo>[];
      final addedColumns = <ColumnInfo>[];
      final removedColumns = <ColumnInfo>[];
      final changedColumns = <ColumnChange>[];
      final baselineRowCount = existsInBaseline
          ? _tableCount(baselineDb, tableName)
          : 0;
      final candidateRowCount = existsInCandidate
          ? _tableCount(candidateDb, tableName)
          : 0;
      final keyColumns = existsInBaseline
          ? _keyColumns(baselineColumns)
          : _keyColumns(candidateColumns);

      final baselineColumnsByName = <String, ColumnInfo>{
        for (final column in baselineColumns) column.name: column,
      };
      final candidateColumnsByName = <String, ColumnInfo>{
        for (final column in candidateColumns) column.name: column,
      };

      for (final column in candidateColumns) {
        final baselineColumn = baselineColumnsByName[column.name];
        if (baselineColumn == null) {
          addedColumns.add(column);
          continue;
        }
        if (!_columnEquals(baselineColumn, column)) {
          changedColumns.add(
            ColumnChange(baseline: baselineColumn, candidate: column),
          );
        }
      }
      for (final column in baselineColumns) {
        if (!candidateColumnsByName.containsKey(column.name)) {
          removedColumns.add(column);
        }
      }

      final addedRows = <RowChange>[];
      final removedRows = <RowChange>[];
      final changedRows = <RowChange>[];

      if (existsInBaseline && existsInCandidate) {
        final baselineRows = _rowsByKey(baselineDb, tableName, keyColumns);
        final candidateRows = _rowsByKey(candidateDb, tableName, keyColumns);
        final allKeys = <String>{
          ...baselineRows.keys,
          ...candidateRows.keys,
        }.toList()..sort();
        final commonColumns = baselineColumns
            .where((column) => candidateColumnsByName.containsKey(column.name))
            .map((column) => column.name)
            .toList();

        for (final key in allKeys) {
          final baselineRow = baselineRows[key];
          final candidateRow = candidateRows[key];
          if (baselineRow == null && candidateRow != null) {
            addedRows.add(
              RowChange(
                key: _extractKeyMap(candidateRow, keyColumns),
                candidateRow: candidateRow,
              ),
            );
            continue;
          }
          if (baselineRow != null && candidateRow == null) {
            removedRows.add(
              RowChange(
                key: _extractKeyMap(baselineRow, keyColumns),
                baselineRow: baselineRow,
              ),
            );
            continue;
          }
          if (baselineRow == null || candidateRow == null) {
            continue;
          }

          final differences = <String, ValueChange>{};
          for (final columnName in commonColumns) {
            final baselineValue = baselineRow[columnName];
            final candidateValue = candidateRow[columnName];
            if (!_valuesEqual(baselineValue, candidateValue)) {
              differences[columnName] = ValueChange(
                baseline: baselineValue,
                candidate: candidateValue,
              );
            }
          }
          if (differences.isNotEmpty) {
            changedRows.add(
              RowChange(
                key: _extractKeyMap(candidateRow, keyColumns),
                baselineRow: baselineRow,
                candidateRow: candidateRow,
                differences: differences,
              ),
            );
          }
        }
      }

      tables.add(
        TableDiff(
          name: tableName,
          existsInBaseline: existsInBaseline,
          existsInCandidate: existsInCandidate,
          baselineColumns: baselineColumns,
          candidateColumns: candidateColumns,
          keyColumns: keyColumns,
          baselineRowCount: baselineRowCount,
          candidateRowCount: candidateRowCount,
          addedColumns: addedColumns,
          removedColumns: removedColumns,
          changedColumns: changedColumns,
          addedRows: addedRows,
          removedRows: removedRows,
          changedRows: changedRows,
        ),
      );
    }

    return DatabaseDiff(
      baselinePath: baselinePath,
      candidatePath: candidatePath,
      startedAt: startedAt,
      completedAt: DateTime.now().toUtc(),
      tables: tables,
    );
  } finally {
    baselineDb.dispose();
    candidateDb.dispose();
  }
}

List<String> _tableNames(Database db) {
  return db
      .select(
        "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name;",
      )
      .map((row) => row['name'] as String)
      .toList();
}

List<ColumnInfo> _tableInfo(Database db, String tableName) {
  return db
      .select('PRAGMA table_info(${_quoteIdentifier(tableName)});')
      .map(
        (row) => ColumnInfo(
          name: row['name'] as String? ?? '',
          type: row['type'] as String? ?? '',
          notNull: (row['notnull'] as int? ?? 0) == 1,
          defaultValue: row['dflt_value'],
          primaryKeyPosition: row['pk'] as int? ?? 0,
        ),
      )
      .toList();
}

int _tableCount(Database db, String tableName) {
  final result = db.select(
    'SELECT COUNT(*) AS cnt FROM ${_quoteIdentifier(tableName)};',
  );
  return result.first['cnt'] as int;
}

List<String> _keyColumns(List<ColumnInfo> columns) {
  final primaryKeyColumns =
      columns.where((column) => column.primaryKeyPosition > 0).toList()..sort(
        (left, right) =>
            left.primaryKeyPosition.compareTo(right.primaryKeyPosition),
      );
  if (primaryKeyColumns.isNotEmpty) {
    return primaryKeyColumns.map((column) => column.name).toList();
  }
  if (columns.any((column) => column.name == 'isar_id')) {
    return <String>['isar_id'];
  }
  return columns.map((column) => column.name).toList();
}

Map<String, Map<String, Object?>> _rowsByKey(
  Database db,
  String tableName,
  List<String> keyColumns,
) {
  final rows = db.select('SELECT * FROM ${_quoteIdentifier(tableName)};');
  final keyedRows = <String, Map<String, Object?>>{};
  for (final row in rows) {
    final rowMap = <String, Object?>{for (final key in row.keys) key: row[key]};
    final signature = _keySignature(rowMap, keyColumns);
    keyedRows[signature] = rowMap;
  }
  return keyedRows;
}

Map<String, Object?> _extractKeyMap(
  Map<String, Object?> row,
  List<String> keyColumns,
) {
  return <String, Object?>{
    for (final keyColumn in keyColumns)
      keyColumn: _normalizeValue(row[keyColumn]),
  };
}

String _keySignature(Map<String, Object?> row, List<String> keyColumns) {
  return jsonEncode(
    keyColumns.map((column) => _normalizeValue(row[column])).toList(),
  );
}

bool _columnEquals(ColumnInfo left, ColumnInfo right) {
  return left.name == right.name &&
      left.type == right.type &&
      left.notNull == right.notNull &&
      left.primaryKeyPosition == right.primaryKeyPosition &&
      _valuesEqual(left.defaultValue, right.defaultValue);
}

bool _valuesEqual(Object? left, Object? right) {
  if (left == null && right == null) {
    return true;
  }
  if (left == null || right == null) {
    return false;
  }
  if (left is Uint8List && right is Uint8List) {
    if (left.lengthInBytes != right.lengthInBytes) {
      return false;
    }
    for (var index = 0; index < left.lengthInBytes; index++) {
      if (left[index] != right[index]) {
        return false;
      }
    }
    return true;
  }
  if (left is num && right is num) {
    return left == right;
  }
  return left == right;
}

Object? _normalizeValue(Object? value) {
  if (value is Uint8List) {
    return base64Encode(value);
  }
  return value;
}

Map<String, Object?> _normalizeMap(Map<String, Object?> row) {
  return <String, Object?>{
    for (final entry in row.entries) entry.key: _normalizeValue(entry.value),
  };
}

String _quoteIdentifier(String identifier) {
  return '"${identifier.replaceAll('"', '""')}"';
}
